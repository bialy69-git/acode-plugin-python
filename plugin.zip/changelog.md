# Acode Python Plugin Changelog

## 1.1.3

- Updated Pyodide library to 0.28.1

## 1.1.1

- Initial release
